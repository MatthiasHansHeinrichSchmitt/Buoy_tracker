// generated from rosidl_generator_c/resource/idl.h.em
// with input from p_interfaces:srv/ChangeRadius.idl
// generated code does not contain a copyright notice

#ifndef P_INTERFACES__SRV__CHANGE_RADIUS_H_
#define P_INTERFACES__SRV__CHANGE_RADIUS_H_

#include "p_interfaces/srv/detail/change_radius__struct.h"
#include "p_interfaces/srv/detail/change_radius__functions.h"
#include "p_interfaces/srv/detail/change_radius__type_support.h"

#endif  // P_INTERFACES__SRV__CHANGE_RADIUS_H_
