// generated from rosidl_generator_c/resource/idl.h.em
// with input from p_action_interfaces:action/GoToPoint.idl
// generated code does not contain a copyright notice

#ifndef P_ACTION_INTERFACES__ACTION__GO_TO_POINT_H_
#define P_ACTION_INTERFACES__ACTION__GO_TO_POINT_H_

#include "p_action_interfaces/action/detail/go_to_point__struct.h"
#include "p_action_interfaces/action/detail/go_to_point__functions.h"
#include "p_action_interfaces/action/detail/go_to_point__type_support.h"

#endif  // P_ACTION_INTERFACES__ACTION__GO_TO_POINT_H_
