// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef P_ACTION_INTERFACES__ACTION__GO_TO_POINT_HPP_
#define P_ACTION_INTERFACES__ACTION__GO_TO_POINT_HPP_

#include "p_action_interfaces/action/detail/go_to_point__struct.hpp"
#include "p_action_interfaces/action/detail/go_to_point__builder.hpp"
#include "p_action_interfaces/action/detail/go_to_point__traits.hpp"
#include "p_action_interfaces/action/detail/go_to_point__type_support.hpp"

#endif  // P_ACTION_INTERFACES__ACTION__GO_TO_POINT_HPP_
