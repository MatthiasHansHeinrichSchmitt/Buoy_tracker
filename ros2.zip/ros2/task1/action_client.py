import rcply
from rclpy.action import ActionClient
from rclpy.action import Node
import time
from p_action_interface.action import GoToPoint


def send_goal(self)
x,y = self.edges